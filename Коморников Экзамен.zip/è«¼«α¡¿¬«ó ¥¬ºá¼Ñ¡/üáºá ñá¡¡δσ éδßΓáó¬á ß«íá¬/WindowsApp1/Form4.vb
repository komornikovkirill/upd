﻿Public Class Form4
    Private Sub ЭкспертыBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles ЭкспертыBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.ЭкспертыBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Выставка_собакDataSet)

    End Sub

    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: данная строка кода позволяет загрузить данные в таблицу "Выставка_собакDataSet.Эксперты". При необходимости она может быть перемещена или удалена.
        Me.ЭкспертыTableAdapter.Fill(Me.Выставка_собакDataSet.Эксперты)

    End Sub
End Class