﻿Public Class Form3
    Private Sub УчастникиBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles УчастникиBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.УчастникиBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Выставка_собакDataSet)

    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: данная строка кода позволяет загрузить данные в таблицу "Выставка_собакDataSet.Участники". При необходимости она может быть перемещена или удалена.
        Me.УчастникиTableAdapter.Fill(Me.Выставка_собакDataSet.Участники)

    End Sub
End Class