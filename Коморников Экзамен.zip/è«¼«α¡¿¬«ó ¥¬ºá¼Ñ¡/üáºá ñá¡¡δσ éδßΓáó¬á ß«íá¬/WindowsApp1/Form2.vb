﻿Public Class Form2
    Private Sub КлубыBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles КлубыBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.КлубыBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Выставка_собакDataSet)

    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: данная строка кода позволяет загрузить данные в таблицу "Выставка_собакDataSet.Клубы". При необходимости она может быть перемещена или удалена.
        Me.КлубыTableAdapter.Fill(Me.Выставка_собакDataSet.Клубы)

    End Sub
End Class